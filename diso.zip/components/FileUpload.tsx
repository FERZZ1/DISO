import React, { useRef, useState } from 'react';
import { Upload, Video, Image as ImageIcon } from 'lucide-react';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  disabled?: boolean;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, disabled }) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    if (!disabled) setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (disabled) return;

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFileSelect(e.target.files[0]);
    }
  };

  return (
    <div
      onClick={() => !disabled && fileInputRef.current?.click()}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`
        relative w-full h-64 rounded-2xl border-2 border-dashed transition-all duration-300 cursor-pointer flex flex-col items-center justify-center gap-4 group
        ${isDragging 
          ? 'border-emerald-500 bg-emerald-500/10' 
          : 'border-zinc-700 hover:border-emerald-500/50 hover:bg-zinc-800/50 bg-zinc-900/30'
        }
        ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
      `}
    >
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleChange}
        accept="image/*,video/*"
        className="hidden"
        disabled={disabled}
      />
      
      <div className={`p-4 rounded-full bg-zinc-800 transition-transform duration-300 group-hover:scale-110 ${isDragging ? 'scale-110 bg-emerald-500/20' : ''}`}>
        <Upload className={`w-8 h-8 ${isDragging ? 'text-emerald-400' : 'text-zinc-400 group-hover:text-emerald-400'}`} />
      </div>
      
      <div className="text-center">
        <p className="text-zinc-200 font-medium text-lg">
          {isDragging ? 'Drop to Analyze' : 'Upload Image or Video'}
        </p>
        <p className="text-zinc-500 text-sm mt-1">
          JPG, PNG, MP4, WEBM supported
        </p>
      </div>
    </div>
  );
};

export default FileUpload;