import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AnalysisResult } from "../types";

const GEMINI_API_KEY = process.env.API_KEY || '';

const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });

const analysisSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    isAiGenerated: {
      type: Type.BOOLEAN,
      description: "Whether the media is likely AI generated.",
    },
    confidenceScore: {
      type: Type.NUMBER,
      description: "Confidence score between 0 and 100.",
    },
    verdict: {
      type: Type.STRING,
      description: "A short summary title of the analysis (e.g., 'Likely AI-Generated Video' or 'Authentic Footage').",
    },
    reasoning: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "List of reasons supporting the verdict.",
    },
    artifactsFound: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Specific visual artifacts detected (e.g., 'Morphing hands', 'Inconsistent shadows', 'Object flickering').",
    },
    technicalDetails: {
      type: Type.OBJECT,
      properties: {
        lightingConsistency: { type: Type.STRING },
        textureQuality: { type: Type.STRING },
        anatomicalAccuracy: { type: Type.STRING },
        metadataAnalysis: { type: Type.STRING },
        temporalConsistency: { type: Type.STRING, description: "For videos only: Analysis of motion stability and object permanence." },
      },
      required: ["lightingConsistency", "textureQuality"],
    },
  },
  required: ["isAiGenerated", "confidenceScore", "verdict", "reasoning", "artifactsFound", "technicalDetails"],
};

export const analyzeMedia = async (base64Data: string, mimeType: string): Promise<AnalysisResult> => {
  if (!GEMINI_API_KEY) {
    throw new Error("MISSING_API_KEY");
  }

  try {
    const isVideo = mimeType.startsWith('video/');
    
    const prompt = isVideo 
      ? `Analyze this video for signs of Artificial Intelligence generation. 
         Act as a digital forensics expert. Scrutinize the video frames for:
         1. Temporal inconsistencies (morphing objects, flickering textures, shape instability).
         2. Physics violations (unnatural gravity, momentum, collisions, fluid dynamics).
         3. Anatomical consistency in motion (limbs bending wrongly, faces distorting while turning).
         4. Background stability (warping, static elements moving).
         5. AI artifacts specific to video (shimmering, ghosting, frame interpolation errors).
         
         IMPORTANT: Ensure you populate the 'temporalConsistency' field in technicalDetails with your observations on motion stability.`
      : `Analyze this image for signs of Artificial Intelligence generation. 
         Act as a digital forensics expert. Scrutinize the image for:
         1. Physical inconsistencies (shadows, reflections, gravity).
         2. Anatomical errors (hands, eyes, teeth, hair blending).
         3. Text rendering artifacts (gibberish, inconsistent fonts).
         4. Texture issues (over-smoothing, painterly effects, noise patterns).
         5. Background logic.
         
         Provide a strict probability assessment.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: base64Data,
            },
          },
          {
            text: prompt,
          },
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
        temperature: 0.2, // Low temperature for analytical precision
      },
    });

    if (response.text) {
      return JSON.parse(response.text) as AnalysisResult;
    } else {
      throw new Error("NO_RESPONSE_TEXT");
    }
  } catch (error) {
    console.error("Analysis failed:", error);
    throw error;
  }
};